//author: Kamran A-eff

(function ($) {

    let link = $(`<style/>`);
    $(document.head).append(link);

    $(link).html(`.img-plus{ 
        display: flex;
        justify-content: center;
        align-items: center
    }
    
    .img-plus-no-bt{        
        outline: none;
        border: none;
        color: #7fad39;
        background-color: transparent
    }

    .img-thumb{        
        cursor: pointer;
        background-size: cover;
        background-position: center;
        position: relative;
        z-index:0;
    }

    .imager > .img-thumb:not(:last-of-type) {
        margin-right: 10px;
    }

    .img-thumb input[type='file'],
    .img-thumb input[type='radio']{
        display:none;
    }

    .imager-rio{
        display:none;
    }
    .imager-rio{
        display:none;
    }

    .imager-rio:checked+label.img-thumb::before {
        content: '';
        display: inline;
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        background-color: #f3f6fb9e;
        z-index: 1;
    }

    .imager-rio:checked+label.img-thumb::after {
        font: normal normal normal 28px/1 FontAwesome;
        content: '\\f00c';
        display: inline;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 2;
        color: #7fad39;
    }
    `);

    $.makeid = function (length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    };

    $.fn.imgadd = function (options) {
        let that = this;

        options = $.extend(options, {
            viewer: '#viewer',
            tnWidth: '120px',
            tnHeight: '120px',
            fontSize: '55px',
            plusInnerHtml: '<i class="fa fa-image"></i>',
            plusBtnClass: undefined,
            applyBootstrap: true
        });

        console.log(options);

        $(that).each(function (index, element) {

            if (options.applyBootstrap) {
                $(element).addClass('d-flex flex-wrap');
            }

            let guid = $.makeid(8);
            console.log(guid);

            let btnPlus = $(`<button class='img-plus' type='button'>${options.plusInnerHtml}</button>`)
                .css({
                    width: options.tnWidth,
                    height: options.tnHeight,
                });

            if (options.plusBtnClass) {
                $(btnPlus).addClass(options.plusBtnClass);
            }
            else {
                $(btnPlus).css({
                    'font-size': options.fontSize
                })
                    .addClass('img-plus-no-bt');
            }

            let ix = 1;
            let elName = $(element).attr('name');
            $(btnPlus).click(function () {
                let hasEmpty = false;

                $(element).find('input:file').each(function (i, e) {

                    if ($(e).val() == '') {
                        hasEmpty = true;
                        $(e).trigger('click');
                    }

                });

                if (hasEmpty)
                    return;


                let fileInput = $(`<input name='${elName}' type="file" accept="image/x-png,image/gif,image/jpeg"/>`);

                let label = $(`<label for='${guid}-${ix}' class='img-thumb' style="background-image:url('assets/img/img-rendering.gif')"></label>`)
                    .append(fileInput)
                    .css({
                        width: options.tnWidth,
                        height: options.tnHeight
                    })
                    .insertBefore(btnPlus);

                $(`<input value='${ix - 1}' name='${elName}SelectedIndex' id='${guid}-${ix}' type='radio' class="imager-rio">`)
                    .insertBefore(label);

                $(fileInput).change(function (e) {
                    $(label).attr('title', e.target.files[0].name);

                    let reader = new FileReader();
                    reader.addEventListener("load", function () {
                        $(label).css({
                            'background-image': `url(${reader.result})`
                        }).unbind('click')
                            .click(function () {
                                $(options.viewer).attr('src', reader.result)
                            });

                        if ($(that).find('input:checked').length == 0)
                            $(label).trigger('click');
                    }, false);

                    reader.readAsDataURL(e.target.files[0]);
                });
                ix++;
                $(fileInput).trigger('click');
            });
            $(element).append(btnPlus);
        });

    }


})(jQuery);